package in.ashar.twodatabases;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwodatabasesApplicationTests {

	@Test
	void contextLoads() {
	}

}
