package in.ashar.twodatabases;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwodatabasesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwodatabasesApplication.class, args);
	}

}
